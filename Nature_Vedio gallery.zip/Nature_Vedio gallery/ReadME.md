# 🌿 Nature Video Gallery

A professional, responsive nature-themed video gallery built using **HTML5**, **CSS Flexbox**, and **vanilla JavaScript**. This project displays 25 high-quality, muted nature videos organized into categories: **Mountains**, **Oceans**, and **Forests**. The design is mobile-friendly and uses semantic HTML structure.

---

## 🛠 What I Built

- A video gallery with 25 short, high-resolution nature videos
- Filtering functionality to view videos by category
- Responsive layout using CSS Flexbox (5 videos per row on desktop)
- Styled with a clean, nature-themed color palette and Google Fonts
- Semantic HTML5 elements for accessibility and clarity

---

## 💡 HTML & CSS Choices

### HTML:
- Used semantic tags: `<header>`, `<nav>`, `<main>`, `<section>`, `<article>`, `<footer>` for better structure and accessibility
- `<video>` tag with `controls`, `muted`, and `poster` for clean user experience
- `data-category` attributes for filtering with JavaScript

### CSS:
- **Flexbox** used for responsive layout with `flex-wrap` and `calc()` for 5 videos per row
- **Media queries** for adapting layout to smaller screens (4, 3, 2, 1 videos per row)
- **Hover effects** for interactivity and polish (e.g., scale and shadow on videos)
- Nature-inspired theme using greens and neutral colors

---

## 🚀 How to Run the Project

1. Clone or download the project folder  
2. Open the `index.html` file in any web browser  
3. Make sure all media files are located in the `media/` folder  
4. To view the gallery online, you can host it on GitHub Pages, Netlify, or Vercel

---

## 📁 Project Structure

