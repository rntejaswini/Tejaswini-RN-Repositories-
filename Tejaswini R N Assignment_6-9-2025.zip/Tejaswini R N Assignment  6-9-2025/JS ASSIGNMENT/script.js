// =============================
// A) formatMoney
// =============================
function formatMoney(value, decimals) {
  if (!Number.isFinite(value)) return "Invalid";
  return value.toFixed(decimals);
}

// =============================
// B) formatSignificant
// =============================
function formatSignificant(value, sigDigits) {
  if (!Number.isFinite(value)) return "Invalid";
  return value.toPrecision(sigDigits);
}

// =============================
// C) formatScientific
// =============================
function formatScientific(value, fractionDigits) {
  if (!Number.isFinite(value)) return "Invalid";
  return value.toExponential(fractionDigits);
}

// =============================
// D) safeParseNumber
// =============================
function safeParseNumber(input) {
  input = input.trim();
  let num = Number(input);
  if (!Number.isNaN(num)) return num;

  let int = Number.parseInt(input);
  return Number.isNaN(int) ? NaN : int;
}

// =============================
// E) isSafeCounterNo
// =============================
function isSafeCounterNo(n) {
  return Number.isSafeInteger(n);
}

// =============================
// F) addMoney
// =============================
function addMoney(a, b) {
  let sum = a + b;
  if (Math.abs(sum - Math.round(sum)) < 10 * Number.EPSILON) {
    return Math.round(sum);
  }
  if (Math.abs(sum * 100 - Math.round(sum * 100)) < 10 * Number.EPSILON * 100) {
    return Math.round(sum * 100) / 100;
  }
  return sum;
}

// =============================
// DEMO: run all functions
// =============================
function demoAll() {
  let val = document.getElementById("numInput").value;
  let parsed = safeParseNumber(val);

  let results = [];
  results.push("Original Input: " + val);
  results.push("Parsed Number: " + parsed);

  results.push("A) formatMoney(,2): " + formatMoney(parsed, 2));
  results.push("B) formatSignificant(,3): " + formatSignificant(parsed, 3));
  results.push("C) formatScientific(,2): " + formatScientific(parsed, 2));
  results.push("E) isSafeCounterNo: " + isSafeCounterNo(parsed));

  // Example for addMoney
  results.push("F) addMoney(0.1,0.2): " + addMoney(0.1, 0.2));
  results.push("F) addMoney(1.005,0): " + addMoney(1.005, 0));

  document.getElementById("output").innerText = results.join("\n");
}
