# Number Formatting & Safety in JavaScript

## 📌 What I Built
A small **Numeric Formatter & Validator** tool that demonstrates how to safely format and validate numbers in JavaScript using built-in methods. It includes currency formatting, significant digits, scientific notation, safe parsing, integer safety checks, and precise addition.

## 🛠️ Features Used
- **HTML**: Semantic tags (`<header>`, `<main>`, `<section>`, `<article>`, `<footer>`) for structure.  
- **CSS**: Styling with colors, layout, and hover effects.  
- **JavaScript**: Number methods (`toFixed`, `toPrecision`, `toExponential`), safety checks (`isFinite`, `isNaN`, `isSafeInteger`, `EPSILON`), and parsing (`Number`, `parseInt`, `parseFloat`).  

## ▶️ How to Run
1. Open `index.html` in any browser.  
2. Enter a number and click **Run All Functions**.  
3. Results will display in the output section.  

## ⚠️ Assumptions / Limitations
- Input is taken as string and parsed safely.  
- Works for standard decimal and integer numbers.  
- Some results (like scientific notation) depend on JavaScript engine formatting.  
