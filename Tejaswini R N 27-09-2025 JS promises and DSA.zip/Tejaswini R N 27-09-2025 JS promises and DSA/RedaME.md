# Restaurant Simulation with Promises

## 📖 What I Built
I created a restaurant simulation system that mimics the process of ordering, cooking, and serving food.  
Each step is asynchronous and handled using **JavaScript Promises**.

## 🚀 JavaScript Features Used
- **Promises** to handle asynchronous tasks.
- **.then()** for success chaining (order → cook → serve).
- **.catch()** to handle any error gracefully.
- **.finally()** to always log "Restaurant closing...", no matter success or failure.

## 🛠️ How to Run
1. Save the file as `restaurant.html`.
2. Open it in any browser OR run it in Node.js by moving the script part into `restaurant.js`.
3. Open console (F12 → Console tab) to see outputs.

## 📌 Assumptions / Limitations
- Uses `setTimeout` to simulate delays (1s for order, 2s for cook, 1s for serve).
- Success or failure depends on input values (`true` or `false` passed to the functions).
- No frontend (HTML/CSS), only console outputs.
- Works in any JavaScript environment (browser or Node.js).
