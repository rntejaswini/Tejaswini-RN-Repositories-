# Find Minimum in Rotated Sorted Array (LeetCode 153) – Java Solution

## 📖 What I Built
I implemented a Java solution to efficiently find the minimum element in a rotated sorted array of unique integers.  
The algorithm runs in **O(log n)** time using binary search, making it suitable for large arrays.

## 🚀 Java Features Used
- **Binary Search** logic for logarithmic time complexity.
- Simple arithmetic operations and array indexing.
- No additional data structures used (space complexity O(1)).