# Text Processing Utility

## 📌 About
This project is a **Text Processing Utility** built with **HTML, CSS, and JavaScript**.  
It allows users to perform basic string operations like extracting words, joining, replacing, trimming, converting to uppercase, and splitting into words.

## 🛠 Features
- Get first character
- Join two strings
- Extract substring using slice
- Replace words
- Clean spaces & convert to uppercase
- Split into array of words

## 💻 Tech Used
- **HTML5** (semantic tags like `<header>`, `<main>`, `<footer>`)  
- **CSS3** (basic styling, hover effects, responsive layout)  
- **JavaScript** (string methods: `charAt`, `concat`, `slice`, `replace`, `trim`, `split`, `toUpperCase`)  

## 🚀 How to Run
1. Clone or download this project.  
2. Place all files in a single folder (with `Images/favicon.png`).  
3. Open `index.html` in a browser.  

## ⚠️ Assumptions / Limitations
- Input is treated as plain text (no regex or advanced parsing).  
- Splitting uses `" "` (space) only, not punctuation.  

---
