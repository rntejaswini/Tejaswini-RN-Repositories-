// =============================
// A) getFirstChar
// =============================
function getFirstChar(str) {
  if (str.length === 0) return "";
  return str.charAt(0);
}

// =============================
// B) joinStrings
// =============================
function joinStrings(str1, str2) {
  return str1.concat(str2);
}

// =============================
// C) extractWord
// =============================
function extractWord(str, start, end) {
  return str.slice(start, end);
}

// =============================
// D) replaceWord
// =============================
function replaceWord(str, oldWord, newWord) {
  return str.replace(oldWord, newWord);
}

// =============================
// E) cleanAndUpper
// =============================
function cleanAndUpper(str) {
  return str.trim().toUpperCase();
}

// =============================
// F) splitIntoWords
// =============================
function splitIntoWords(str) {
  return str.split(" ");
}

// =============================
// UI Test Functions
// =============================
function testGetFirstChar() {
  const input = document.getElementById("inputText").value;
  document.getElementById("output").textContent = getFirstChar(input);
}

function testJoinStrings() {
  document.getElementById("output").textContent = joinStrings("Tejas", "_wini");
}

function testExtractWord() {
  document.getElementById("output").textContent = extractWord("Kalpataru", 4, 10);
}

function testReplaceWord() {
  document.getElementById("output").textContent = replaceWord("Student ", "of", "ISE");
}

function testCleanAndUpper() {
  const input = document.getElementById("inputText").value;
  document.getElementById("output").textContent = cleanAndUpper(input);
}

function testSplitIntoWords() {
  const input = document.getElementById("inputText").value;
  document.getElementById("output").textContent = JSON.stringify(splitIntoWords(input));
}
