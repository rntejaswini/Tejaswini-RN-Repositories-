function greet(name, callback) {
    console.log(`Hello, ${name}!`);
    callback();
}

greet("Tejaswini", function() {
    console.log("Welcome to Asynchronous JS assignment!\n");
});


function task1(callback) {
    setTimeout(() => {
        console.log("Task 1 completed");
        callback();
    }, 1000);
}

function task2(callback) {
    setTimeout(() => {
        console.log("Task 2 completed");
        callback();
    }, 2000);
}

function task3(callback) {
    setTimeout(() => {
        console.log("Task 3 completed");
        callback();
    }, 1000);
}


console.log("--- Callback Hell Simulation ---");
task1(() => {
    task2(() => {
        task3(() => {
            console.log("All tasks completed successfully!\n");
        });
    });
});


function taskWithError(taskName, duration, callback) {
    setTimeout(() => {
        if (Math.random() < 0.5) {
            callback(` ${taskName} failed`);
        } else {
            console.log(`${taskName} completed`);
            callback(null);
        }
    }, duration);
}

console.log("--- Callback with Error Handling ---");
taskWithError("Task 1", 1000, (err) => {
    if (err) { console.log(err); return; }
    taskWithError("Task 2", 2000, (err) => {
        if (err) { console.log(err); return; }
        taskWithError("Task 3", 1000, (err) => {
            if (err) { console.log(err); return; }
            console.log("All tasks completed successfully!\n");
        });
    });
});


function taskPromise(taskName, duration) {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            if (Math.random() < 0.5) {
                reject(` ${taskName} failed`);
            } else {
                console.log(`${taskName} completed`);
                resolve();
            }
        }, duration);
    });
}

console.log("--- Promises Simulation ---");
taskPromise("Task 1", 1000)
    .then(() => taskPromise("Task 2", 2000))
    .then(() => taskPromise("Task 3", 1000))
    .then(() => console.log("All tasks completed successfully!\n"))
    .catch((err) => {
        console.log(err);
        console.log("Task execution stopped due to error.\n");
    });


async function runTasks() {
    console.log("--- Async/Await Simulation ---");
    try {
        await taskPromise("Task 1", 1000);
        await taskPromise("Task 2", 2000);
        await taskPromise("Task 3", 1000);
        console.log("All tasks completed successfully!\n");
    } catch (err) {
        console.log(err);
        console.log("Task execution stopped due to error.\n");
    }
}

runTasks();
