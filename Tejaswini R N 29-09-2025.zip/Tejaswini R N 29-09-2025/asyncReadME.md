Callbacks – For basic async task execution.

Callback Hell Simulation – Nested callbacks to show sequential async tasks.

Error Handling in Callbacks – 50% chance to fail a task.

Promises – For cleaner sequential task execution with .then()/.catch().

Async/Await – Modern syntax to run tasks sequentially with try...catch for error handling.

Timers – setTimeout() used to simulate asynchronous delays.