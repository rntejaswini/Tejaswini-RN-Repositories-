# Product of Array Except Self - Java Solution

## Description

Given an integer array `nums`, the program returns an array `answer` such that `answer[i]` is equal to the product of all elements of `nums` except `nums[i]`.  
The solution is implemented in Java **without using division** and runs in **O(n) time**.

---

## Features
- Computes the product of array elements **except self**.
- Handles zeros correctly.
- Runs in **O(n) time** with **O(1) extra space** (excluding the output array).
- Uses **prefix and suffix products** to avoid division.
- Includes a test driver to demonstrate the solution with sample inputs.

---

## Java Features Used
- Arrays and array manipulation.
- Loops (`for` loops) for prefix and suffix calculations.
- `Arrays.toString()` for printing arrays.
- Class-based structure (`Solution` class for the function, `Main` class as driver).

---

## How to Run
1. Save the Java code in a file, e.g., `Main.java`.
2. Compile the Java file:
   ```bash
   javac Main.java
