# CSS Box Model Assignment

## 📌 What I Built
I created a webpage that visually represents the **CSS Box Model** including Content, Padding, Border, and Margin. Each layer is styled with different colors, labeled, and outlined to clearly show the structure.

## 📌 HTML & CSS Used
- **HTML:** `<section>`, `<div>`, `<p>`, `<header>`, `<main>`, `<footer>` for semantic structure.
- **CSS Properties:** 
  - `margin`, `padding`, `border`, and `outline` to demonstrate the box model.
  - `background-color` for visual distinction.
  - `hover` effects for interactivity.
  - `flexbox` for centering content.

## 📌 How to Run
1. Open `index.html` in any modern browser.
2. Ensure the `style.css` file and `Images/` folder are in the same directory.

## 📌 Assumptions / Limitations
- Colors are chosen for contrast but can be customized.
- Only HTML + CSS (no JavaScript used).
- Works best on desktop view.
