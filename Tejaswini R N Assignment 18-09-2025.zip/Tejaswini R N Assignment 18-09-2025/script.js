// Task Array
let tasks = [];
let taskIdCounter = 1;

// Add Task
document.getElementById("taskForm").addEventListener("submit", function (e) {
  e.preventDefault();

  const title = document.getElementById("title").value;
  const description = document.getElementById("description").value;
  const dueDate = new Date(document.getElementById("dueDate").value);

  const task = {
    id: taskIdCounter++,
    title,
    description,
    dueDate,
    status: "pending"
  };

  tasks.push(task);
  document.getElementById("taskForm").reset();
  renderTasks(tasks);
  updateCountdown();
});

// Render Tasks
function renderTasks(taskArray) {
  const taskList = document.getElementById("taskList");
  taskList.innerHTML = "";

  const today = new Date();

  taskArray.forEach(task => {
    const taskDiv = document.createElement("div");
    taskDiv.classList.add("task");

    // Check status
    if (task.status === "completed") {
      taskDiv.classList.add("completed");
    } else if (task.dueDate < today && task.status !== "completed") {
      taskDiv.classList.add("overdue");
    } else {
      taskDiv.classList.add("pending");
    }

    taskDiv.innerHTML = `
      <h3>${task.title}</h3>
      <p>${task.description}</p>
      <p><strong>Due:</strong> ${task.dueDate.toLocaleDateString()}</p>
      <p><strong>Status:</strong> ${task.status}</p>
      ${task.status === "pending" ? `<button onclick="markComplete(${task.id})">Mark Complete</button>` : ""}
    `;

    taskList.appendChild(taskDiv);
  });
}

// Mark Complete
function markComplete(taskId) {
  const task = tasks.find(t => t.id === taskId);
  if (task) {
    task.status = "completed";
  }
  renderTasks(tasks);
  updateCountdown();
}

// Show Today's Tasks
function showTodayTasks() {
  const today = new Date();
  const todayTasks = tasks.filter(t =>
    t.dueDate.getDate() === today.getDate() &&
    t.dueDate.getMonth() === today.getMonth() &&
    t.dueDate.getFullYear() === today.getFullYear()
  );
  renderTasks(todayTasks);
}

// Show All Tasks
function showAllTasks() {
  renderTasks(tasks);
}

// Countdown Timer for nearest task
function updateCountdown() {
  const countdownEl = document.getElementById("countdown");
  const pendingTasks = tasks.filter(t => t.status === "pending" && t.dueDate >= new Date());

  if (pendingTasks.length === 0) {
    countdownEl.textContent = "No upcoming tasks";
    return;
  }

  // Sort by earliest due date
  pendingTasks.sort((a, b) => a.dueDate - b.dueDate);
  const nextTask = pendingTasks[0];

  function updateTimer() {
    const now = new Date();
    const diff = nextTask.dueDate - now;

    if (diff <= 0) {
      countdownEl.textContent = "Deadline reached!";
      return;
    }

    const days = Math.floor(diff / (1000 * 60 * 60 * 24));
    const hours = Math.floor((diff / (1000 * 60 * 60)) % 24);
    const minutes = Math.floor((diff / (1000 * 60)) % 60);

    countdownEl.textContent = `Next Deadline in: ${days}d ${hours}h ${minutes}m`;
  }

  updateTimer();
  setInterval(updateTimer, 60000); // Update every minute
}
