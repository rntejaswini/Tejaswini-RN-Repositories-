class Solution {
    
    // Compute prefix sum of life(x) from 1..n
    private long prefix(long n) {
        if (n <= 0) return 0;

        long res = 0;
        long k = 1;   // life value for current block
        long p = 1;   // block start (1, 4, 16, 64...)

        while (p <= n) {
            long nxt = Math.min(n, 4 * p - 1);
            res += (nxt - p + 1) * k;
            p *= 4;
            k++;
        }
        return res;
    }

    // Main function required by LeetCode
    public long minOperations(int[][] queries) {
        long ans = 0;
        for (int[] q : queries) {
            long l = q[0], r = q[1];
            long totalLives = prefix(r) - prefix(l - 1);
            ans += (totalLives + 1) / 2;  // ceil division
        }
        return ans;
    }
}
