# Internship Application & Tracker

This project is a simple **Internship Application & Tracker** built using HTML and CSS. It allows users to view internship listings, check skill requirements, apply through a form, and download a guide.

## HTML Structure
- **Semantic Tags Used**:
  - `<header>` for the top title section.
  - `<nav>` for navigation menu.
  - `<main>` as the main container.
  - `<section>` for logically grouped content (Internships, Apply, Resources).
  - `<footer>` for bottom info.
- Used `<table>` to list internships and `<details>` to show/hide required skills.

## CSS Features
- External stylesheet (`styles.css`) for clean code separation.
- Typography: Clear font, readable spacing, headings hierarchy.
- Layout: Max-width content area, spacing, neat alignment.
- Colors: High-contrast color palette for accessibility.
- Buttons/Links: Styled submit button, visible focus outline.
- Navigation: Hover and focus states for accessibility.

## How to Run
- Open `HTML/index.html` directly in any modern web browser (no server needed).

## Assumptions & Limitations
- Only basic validation; no backend or JavaScript used.
- Contact emails are for demo purposes only.
