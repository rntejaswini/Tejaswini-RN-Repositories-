// Updated registered students
const registeredStudents = ["Tejaswini R N", "Ambika N R", "Faiza Tarannum"];

// Today's attendance
let todaysAttendance = new Set();

// Total attendance map
let totalAttendance = new Map();
registeredStudents.forEach(student => totalAttendance.set(student, 0));

// DOM Elements
const studentInput = document.getElementById("student-name");
const markBtn = document.getElementById("mark-attendance-btn");
const errorMsg = document.getElementById("error-msg");
const todayAttendanceDisplay = document.getElementById("today-attendance");

const checkInput = document.getElementById("check-student");
const checkBtn = document.getElementById("check-attendance-btn");
const singleReport = document.getElementById("single-report");
const fullReportBtn = document.getElementById("full-report-btn");
const fullReportList = document.getElementById("full-report");

// Mark attendance
markBtn.addEventListener("click", () => {
    const name = studentInput.value.trim();
    if (!registeredStudents.includes(name)) {
        errorMsg.textContent = "Error: Student not registered.";
        return;
    }
    errorMsg.textContent = "";
    todaysAttendance.add(name);
    totalAttendance.set(name, totalAttendance.get(name) + 1);
    todayAttendanceDisplay.textContent = "Today's attendance: " + [...todaysAttendance].join(", ");
    studentInput.value = "";
});

// Check single student's attendance
checkBtn.addEventListener("click", () => {
    const name = checkInput.value.trim();
    if (!registeredStudents.includes(name)) {
        singleReport.textContent = "Error: Student not registered.";
        return;
    }
    singleReport.textContent = `${name} has attended ${totalAttendance.get(name)} classes`;
    checkInput.value = "";
});

// Show full class report
fullReportBtn.addEventListener("click", () => {
    fullReportList.innerHTML = "";
    registeredStudents.forEach(student => {
        const li = document.createElement("li");
        li.textContent = `${student} → ${totalAttendance.get(student)} classes attended`;
        fullReportList.appendChild(li);
    });
});
