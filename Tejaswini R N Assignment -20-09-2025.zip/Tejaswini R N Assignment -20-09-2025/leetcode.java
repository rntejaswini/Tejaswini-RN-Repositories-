import java.util.*;

public class Solution {
    
    // Helper function to replace vowels with '*'
    private String devowel(String word) {
        return word.toLowerCase().replaceAll("[aeiou]", "*");
    }
    
    public String[] spellchecker(String[] wordlist, String[] queries) {
        Set<String> exact = new HashSet<>();            // Exact words
        Map<String, String> caseMap = new HashMap<>();  // Lowercase -> original
        Map<String, String> vowelMap = new HashMap<>(); // Devowel -> original

        // Preprocessing wordlist
        for (String word : wordlist) {
            exact.add(word);
            String lower = word.toLowerCase();
            caseMap.putIfAbsent(lower, word);
            vowelMap.putIfAbsent(devowel(word), word);
        }

        String[] ans = new String[queries.length];
        
        for (int i = 0; i < queries.length; i++) {
            String query = queries[i];

            if (exact.contains(query)) {
                // Rule 1: Exact match
                ans[i] = query;
            } else {
                String lower = query.toLowerCase();
                String devowel = devowel(query);

                if (caseMap.containsKey(lower)) {
                    // Rule 2: Case-insensitive match
                    ans[i] = caseMap.get(lower);
                } else if (vowelMap.containsKey(devowel)) {
                    // Rule 3: Vowel-error match
                    ans[i] = vowelMap.get(devowel);
                } else {
                    // Rule 4: No match
                    ans[i] = "";
                }
            }
        }
        
        return ans;
    }

    // Test
    public static void main(String[] args) {
        Solution sol = new Solution();

        String[] wordlist1 = {"KiTe","kite","hare","Hare"};
        String[] queries1 = {"kite","Kite","KiTe","Hare","HARE","Hear","hear","keti","keet","keto"};
        System.out.println(Arrays.toString(sol.spellchecker(wordlist1, queries1)));
        // Output: ["kite","KiTe","KiTe","Hare","hare","","","KiTe","","KiTe"]

        String[] wordlist2 = {"yellow"};
        String[] queries2 = {"YellOw"};
        System.out.println(Arrays.toString(sol.spellchecker(wordlist2, queries2)));
        // Output: ["yellow"]
    }
}
