# 📚 Library Book Tracker

## 📌 What I Built
A simple web app to track library books using JavaScript array methods. Users can perform `push()`, `pop()`, `shift()`, `unshift()`, `includes()`, and `indexOf()` operations interactively.

## 🛠 Features Used
- **HTML** → Semantic structure (`header`, `main`, `section`, `footer`), input field, buttons.
- **CSS** → Centered layout, styled buttons with colors, neat borders, responsive UI.
- **JavaScript** → 
  - Array methods for book management.
  - DOM manipulation using `getElementById`.
  - Event handling with button clicks.

## 🚀 How to Run
1. Open `index.html` in any modern browser.
2. Enter book titles (comma-separated).
3. Click buttons to perform operations.
4. See results in the output box.

## 📌 Assumptions & Limitations
- Works only with comma-separated input.
- Supports only the given array operations.
- No database – data resets on page reload.
