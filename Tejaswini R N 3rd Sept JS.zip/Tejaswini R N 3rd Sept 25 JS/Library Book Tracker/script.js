let books = ["Harry Potter", "The Hobbit", "The Alchemist", "Sherlock Holmes"];

function updateOutput(message) {
  document.getElementById("output").innerHTML = 
    `<p>${message}</p><p>📚 Current Books: [ ${books.join(", ")} ]</p>`;
}

function getUserInput() {
  let input = document.getElementById("bookInput").value.trim();
  if (input.length > 0) {
    books = input.split(",").map(book => book.trim());
  }
}

function addBook() {
  getUserInput();
  books.push("Percy Jackson");
  updateOutput("After Adding (Push):");
}

function removeLast() {
  getUserInput();
  books.pop();
  updateOutput("After Removing Last (Pop):");
}

function addAtBeginning() {
  getUserInput();
  books.unshift("Game of Thrones");
  updateOutput("After Adding at Beginning (Unshift):");
}

function removeFirst() {
  getUserInput();
  books.shift();
  updateOutput("After Removing First (Shift):");
}

function checkIncludes() {
  getUserInput();
  let result = books.includes("The Hobbit");
  updateOutput(`Is "The Hobbit" available? ${result}`);
}

function findIndex() {
  getUserInput();
  let position = books.indexOf("The Alchemist");
  updateOutput(`Position of "The Alchemist": ${position}`);
}
