# Internship Application & Tracker

## 📌 What I Built
I created a **pure HTML Internship Application & Tracker** webpage.  
It includes a table of internships, application form, and a download link for a guide.  

## 📌 Semantic HTML Used
- `<header>`: For the main title and page introduction.  
- `<main>`: To contain all main content sections.  
- `<section>`: Divided content into internships, application form, and resources.  
- `<table>`: To display internships in tabular form.  
- `<details>` & `<summary>`: For expandable skill requirements.  
- `<form>`, `<input>`, `<textarea>`: For user application input.  
- `<footer>`: For copyright.

## 📌 How to Open/Run
1. Download the folder.  
2. Open `index.html` directly in any modern browser.  
3. Ensure `Images/favicon.png` exists for favicon display.  
4. Place `Internship_Guide.pdf` in the same folder to enable download.  

## 📌 Assumptions & Limitations
- The project is **pure HTML only** (no CSS/JS).  
- PDF file (`Internship_Guide.pdf`) must be placed in the root folder manually.  
- No backend is implemented, so the form does not store or send data.  

---
