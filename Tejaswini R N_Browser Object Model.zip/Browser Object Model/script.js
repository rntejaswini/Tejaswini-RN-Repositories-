// Helpers
const $ = id => document.getElementById(id);
const addHistory = (text) => {
  const list = $('history-list');
  const item = document.createElement('div');
  item.className = 'history-item';
  const ts = new Date().toLocaleTimeString();
  item.textContent = `${ts} - ${text}`;
  list.prepend(item);
};

// Welcome alert
window.addEventListener('load', () => {
  alert('Welcome to the Browser Dashboard!');
  addHistory('Alert shown: Welcome');
  refreshAllInfo();
  startClock();
});

// CONFIRM quick buttons
$('yes-btn').addEventListener('click', () => {
  addHistory("Confirm: You clicked 'Yes'");
  showBrowserInfo();
});

$('no-btn').addEventListener('click', () => {
  addHistory("Confirm: You clicked 'No'");
  $('name-result').textContent = 'No browser info shown.';
});

// PROMPT form
$('submit-name').addEventListener('click', () => {
  const val = $('name-input').value.trim();
  if (val) {
    $('name-result').textContent = `Hello, ${val}!`;
    addHistory(`Prompt: You entered '${val}'`);
    $('name-input').value = '';
  } else {
    $('name-result').textContent = 'You did not enter a name.';
    addHistory('Prompt: user submitted empty name');
  }
});

// Info panels
function refreshAllInfo() {
  // Window size
  $('win-size').textContent = `innerWidth:  ${window.innerWidth}px
innerHeight: ${window.innerHeight}px
outerWidth:  ${window.outerWidth}px
outerHeight: ${window.outerHeight}px`;

  // Screen
  $('screen-info').textContent = `width: ${screen.width}px
height: ${screen.height}px
availWidth: ${screen.availWidth}px
availHeight: ${screen.availHeight}px`;

  // Location
  const loc = window.location;
  const nav = navigator;
  $('location-info').textContent = `-- LOCATION INFO --
href: ${loc.href}
protocol: ${loc.protocol}
hostname: ${loc.hostname}
pathname: ${loc.pathname}

-- NAVIGATOR INFO --
userAgent: ${nav.userAgent}
platform: ${nav.platform}
language: ${nav.language}`;

  addHistory('Refreshed info panels');
}

function showBrowserInfo() {
  addHistory('Displayed navigator info');
}

// Update info on resize
window.addEventListener('resize', () => {
  refreshAllInfo();
  addHistory('Window resized');
});

// Window methods - popup
let popup = null;

$('open-window').addEventListener('click', () => {
  popup = window.open('https://www.google.com', '_blank', 'width=800,height=600');
  if (popup) {
    addHistory('Opened a new popup window (Google)');
  } else {
    addHistory('Failed to open popup (blocked)');
    alert('Popup blocked. Allow popups to test window.open()');
  }
});

$('close-window').addEventListener('click', () => {
  if (popup && !popup.closed) {
    popup.close();
    addHistory('Closed popup window');
    popup = null;
  } else {
    addHistory('No popup to close');
    alert('No opened popup exists.');
  }
});

$('reload-page').addEventListener('click', () => {
  addHistory('Requested page reload');
  setTimeout(() => location.reload(), 150);
});

$('print-page').addEventListener('click', () => {
  window.print();
  addHistory('Print dialog opened');
});

// Timers
let clockInterval = null;
function startClock() {
  const el = $('clock');
  function tick() { el.textContent = new Date().toLocaleTimeString(); }
  tick();
  clockInterval = setInterval(tick, 1000);
  addHistory('Started live clock');
}

$('start-delay').addEventListener('click', () => {
  $('delayed-msg').textContent = 'Waiting...';
  addHistory('Started 5s delayed message');
  setTimeout(() => {
    $('delayed-msg').textContent = 'Here is your delayed message — 5 seconds passed!';
    addHistory('Displayed delayed message');
  }, 5000);
});

// History controls
$('clear-history').addEventListener('click', () => {
  $('history-list').innerHTML = '';
  addHistory('Cleared interaction history');
});

$('export-history').addEventListener('click', () => {
  const items = Array.from(document.querySelectorAll('.history-item')).map(n => n.textContent);
  console.log('Interaction history export:', items);
  alert('History exported to console. Open devtools to view.');
  addHistory('Exported history to console');
});

// Small keyboard highlight animation
window.addEventListener('keydown', (e) => {
  if (e.key.toLowerCase() === 'h') {
    const histPanel = $('history-list');
    histPanel.style.backgroundColor = '#222';
    histPanel.style.transition = 'background-color 0.3s ease';
    setTimeout(() => {
      histPanel.style.backgroundColor = '';
    }, 500);
    addHistory("Pressed 'H' key — history panel briefly highlighted");
  }
});
