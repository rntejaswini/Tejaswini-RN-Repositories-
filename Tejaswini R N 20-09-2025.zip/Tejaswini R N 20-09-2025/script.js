// ---------------------
// Mouse Events
// ---------------------
const mouseBox = document.getElementById('mouseBox');

mouseBox.addEventListener('click', () => {
    mouseBox.style.backgroundColor = getRandomColor();
});

mouseBox.addEventListener('dblclick', () => {
    mouseBox.style.width = mouseBox.offsetWidth * 2 + 'px';
    mouseBox.style.height = mouseBox.offsetHeight * 2 + 'px';
});

mouseBox.addEventListener('mouseenter', () => console.log('Mouse entered'));
mouseBox.addEventListener('mouseleave', () => console.log('Mouse left'));

mouseBox.addEventListener('mousemove', (e) => {
    mouseBox.textContent = `X: ${e.clientX}, Y: ${e.clientY}`;
});

// Helper function for random color
function getRandomColor() {
    return '#' + Math.floor(Math.random() * 16777215).toString(16);
}

// ---------------------
// Keyboard Events
// ---------------------
const circle = document.getElementById('circle');
let posX = 50;
let posY = 300;
const step = 10;

document.addEventListener('keydown', (e) => {
    switch(e.key) {
        case 'ArrowUp':
            posY -= step;
            break;
        case 'ArrowDown':
            posY += step;
            break;
        case 'ArrowLeft':
            posX -= step;
            break;
        case 'ArrowRight':
            posX += step;
            break;
        case ' ':
            e.preventDefault();
            console.log('Spacebar pressed!');
            circle.style.backgroundColor = getRandomColor();
            break;
    }
    circle.style.top = posY + 'px';
    circle.style.left = posX + 'px';
});

// ---------------------
// Clipboard Events
// ---------------------
const textarea = document.getElementById('clipboardArea');
const copyOutput = document.getElementById('copyOutput');
const cutOutput = document.getElementById('cutOutput');
const pasteOutput = document.getElementById('pasteOutput');

textarea.addEventListener('copy', (e) => {
    const text = window.getSelection().toString() || textarea.value;
    copyOutput.textContent = `Copied: ${text}`;
});

textarea.addEventListener('cut', (e) => {
    const text = window.getSelection().toString() || textarea.value;
    cutOutput.textContent = `Cut: ${text}`;
});

textarea.addEventListener('paste', (e) => {
    e.preventDefault();
    const pasteData = (e.clipboardData || window.clipboardData).getData('text');
    console.log('Pasted text');
    pasteOutput.textContent = pasteData;
    textarea.value += pasteData;
});

// ---------------------
// Drag & Drop Events
// ---------------------
const draggables = document.querySelectorAll('.draggable');
const dropTarget = document.getElementById('dropTarget');

draggables.forEach(item => {
    item.addEventListener('dragstart', (e) => {
        e.dataTransfer.setData('text', e.target.id);
        console.log(`${e.target.textContent} drag started`);
    });
});

dropTarget.addEventListener('dragover', (e) => {
    e.preventDefault();
    dropTarget.style.backgroundColor = 'lightyellow';
});

dropTarget.addEventListener('dragleave', (e) => {
    dropTarget.style.backgroundColor = 'lightgray';
});

dropTarget.addEventListener('drop', (e) => {
    e.preventDefault();
    const id = e.dataTransfer.getData('text');
    const draggedItem = document.getElementById(id);
    dropTarget.style.backgroundColor = 'lightgreen';
    dropTarget.textContent = `Item ${draggedItem.textContent} dropped successfully!`;

    // Optional: Shift key changes color
    if(e.shiftKey) {
        draggedItem.style.backgroundColor = getRandomColor();
    }
});
