# Create Maximum Number – Java Solution

## Project Description
This project implements a solution to the LeetCode problem **“Create Maximum Number”** (Problem 321) in Java.  
Given two integer arrays `nums1` and `nums2` representing digits of two numbers, and an integer `k`, the goal is to create the **maximum number of length k** using digits from both arrays while preserving the relative order of digits from the same array.

## Features / Approach
- **Greedy + Stack + Merge Approach**:
  - Select the maximum subsequence of length `i` from `nums1` and length `k-i` from `nums2`.
  - Merge the two subsequences to form the largest number.
  - Try all possible splits to ensure the overall maximum number is obtained.
- **Helper Functions**:
  - `maxSubsequence(nums, k)`: Finds the largest subsequence of length `k` from an array.
  - `merge(nums1, nums2)`: Merges two subsequences to create the maximum number.
  - `greater(nums1, i, nums2, j)`: Compares two subsequences from indices `i` and `j`.

## How to Run
1. Open the `DSA_Assignment.java` file in any Java IDE (e.g., IntelliJ, Eclipse, VSCode).  
2. Run the `main` method to test the example cases.  
3. Modify the `nums1`, `nums2`, and `k` variables to test custom inputs.  

### Example
```java
int[] nums1 = {3,4,6,5};
int[] nums2 = {9,1,2,5,8,3};
int k = 5;
System.out.println(Arrays.toString(sol.maxNumber(nums1, nums2, k))); // Output: [9,8,6,5,3]
