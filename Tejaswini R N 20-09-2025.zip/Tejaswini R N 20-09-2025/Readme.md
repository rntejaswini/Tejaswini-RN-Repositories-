# Event Explorer – Interactive Web Game

## Project Description
Event Explorer is a mini interactive web page designed to demonstrate various JavaScript events including Mouse, Keyboard, Clipboard, and Drag & Drop. Users can interact with elements on the page, and the page responds dynamically through visual updates and console logs, making it a fun way to explore event handling in JavaScript.

## Implemented Events

### Mouse Events
- **click** → toggles the background color of a box randomly.  
- **dblclick** → doubles the size of the box.  
- **mouseenter / mouseleave** → logs “Mouse entered” or “Mouse left” in the console.  
- **mousemove** → displays current mouse coordinates inside the box.  

### Keyboard Events
- **Arrow keys** → move a small circle around the screen.  
- **Spacebar** → logs “Spacebar pressed!” and changes the circle’s color randomly.  

### Clipboard Events
- **copy** → displays “Copied: <text>” in a separate div.  
- **cut** → displays “Cut: <text>” in a separate div.  
- **paste** → logs “Pasted text” and shows the pasted text in another div.  

### Drag & Drop Events
- **dragstart, dragover, drop** → allows dragging items into a drop target.  
- Drop target displays “Item <name> dropped successfully!” on successful drop.  
- Changes the background color of the drop target when hovered.  
- Optional feature: Press **Shift** while dragging to randomly change the color of the dragged item on drop.  

## How to Run
1. Download or clone the `EventExplorer` folder.  
2. Open `index.html` in any modern browser.  
3. Interact with the elements to see event behaviors both on the page and in the console.  

## File Structure
